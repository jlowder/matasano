For this exercise I deployed the "insta" web server that is included
with the racket language. This needs to be running concurrently with
the test app (test.rkt). In a separate window, start the server with:

racket server.rkt

It will produce output like:

secret key: multicolored
url: http://localhost:8000/servlets/standalone.rkt
